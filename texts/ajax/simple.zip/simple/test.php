<?php // vim:ts=4

$x = $GLOBALS['HTTP_RAW_POST_DATA'];
print($x * $x);

?>
