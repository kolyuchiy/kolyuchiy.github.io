package org.koliamorev.dwr;

public class Calculator {
	public float Square(float num) {
		return num * num;
	}
}
