/**
 * CalculatorSOAPImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package ru.pp.kolia.calculator;

public class CalculatorSOAPImpl implements ru.pp.kolia.calculator.Calculator{
    public double calculatePrice(double distance) throws java.rmi.RemoteException {
        return 50 * distance;
    }

}
