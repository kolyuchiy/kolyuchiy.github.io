/**
 * Calculator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package ru.pp.kolia.calculator;

public interface Calculator extends java.rmi.Remote {
    public double calculatePrice(double distance) throws java.rmi.RemoteException;
}
