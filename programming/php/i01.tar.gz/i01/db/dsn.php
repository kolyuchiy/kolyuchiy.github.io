<?php

$dsn = "mysql://root:root@localhost/blog";

?>
