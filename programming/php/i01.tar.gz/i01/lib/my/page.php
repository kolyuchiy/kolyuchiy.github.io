<?php

class myPage {

}

?>
