class RcptAccess < ActiveRecord::Base
end
