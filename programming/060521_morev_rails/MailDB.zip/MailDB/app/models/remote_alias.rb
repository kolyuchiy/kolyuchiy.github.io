class RemoteAlias < ActiveRecord::Base
end
