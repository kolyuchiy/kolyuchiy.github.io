class Transport < ActiveRecord::Base
end
