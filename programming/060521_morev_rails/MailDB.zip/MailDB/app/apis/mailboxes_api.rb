class MailboxesApi < ActionWebService::API::Base
  api_method :destroy
end
