
void jacobi_iter(double **A, double *x, double *x_old, int n);
unsigned jacobi_solve(double **A, double *x, double e, int n);
