
void gauss_l_factor(double **A, int n);
void gauss_solve_l(double **A, double *x, int n);

